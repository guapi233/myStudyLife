<template lang="html">
  <div class="">
    <header class="index-3wrHN_0">
     <div class="index-3aWEx_0">
      <div aria-label="当前地址：北京市朝阳区，轻点两下重新选择" role="button" class="index-3HQMd_0">
       <svg class="index-HnOPT_0">
        <use xlink:href="#location"></use>
       </svg>
       <span class="index-2RLWJ_0">北京市朝阳区</span>
       <svg class="index-2QfD7_0">
        <use xlink:href="#arrow"></use>
       </svg>
      </div>
     </div>
    </header>
    <div class="search-wrapper" style="position: sticky; top: 0px; z-index: 999;">
     <div role="button" class="search" style="top: 0px; z-index: 999;">
      <a class="content">
       <svg>
        <use xlink:href="#search"></use>
       </svg><span>搜索商家、商品名称</span></a>
     </div>
    </div>
    <div class="mint-swipe toptoons">
     <div class="mint-swipe-items-wrap">
      <div class="mint-swipe-item" style="">
       <section class="toptoon">
        <img src="img/64044fb6df771e9cb42196ae3eeeejpeg.jpeg" />
       </section>
      </div>
      <div class="mint-swipe-item is-active" style="">
       <section class="toptoon">
        <img src="img//db8e07bf6216b37bee4ea2aaf708djpeg.jpeg" />
       </section>
      </div>
     </div>
     <div class="mint-swipe-indicators">
      <div class="mint-swipe-indicator"></div>
      <div class="mint-swipe-indicator is-active"></div>
     </div>
    </div>
    <div>
     <div class="mint-swipe foodentry">
      <div class="mint-swipe-items-wrap">
       <div class="mint-swipe-item is-active">
        <a href="javascript:" role="button">
         <div class="container">
          <img src="img/a867c870b22bc74c87c348b75528djpeg.jpeg" />
          <!---->
         </div><span class="title">美食</span></a>
        <a href="javascript:" role="button">
         <div class="container">
          <img src="img/185f7259ebda19e16123884a60ef2jpeg.jpeg" />
          <!---->
         </div><span class="title">晚餐</span></a>
        <a href="javascript:" role="button">
         <div class="container">
          <img src="img/ef32751cb3b72d783f764f0f2c722jpeg.jpeg" />
          <!---->
         </div><span class="title">商超便利</span></a>
        <a href="javascript:" role="button">
         <div class="container">
          <img src="img/d20d49e5029281b9b73db1c5ec6f9jpeg.jpeg" />
          <!---->
         </div><span class="title">果蔬生鲜</span></a>
        <a href="javascript:" role="button">
         <div class="container">
          <img src="img/b02bd836411c016935d258b300cfejpeg.jpeg" />
          <!---->
         </div><span class="title">大牌5折</span></a>
        <a href="javascript:" role="button">
         <div class="container">
          <img src="img/af108e256ebc9f02db599592ae655jpeg.jpeg" />
          <!---->
         </div><span class="title">医药健康</span></a>
        <a href="javascript:" role="button">
         <div class="container">
          <img src="img/c888acb2c8ba9e0c813f36ec9e90ajpeg.jpeg" />
          <!---->
         </div><span class="title">浪漫鲜花</span></a>
        <a href="javascript:" role="button">
         <div class="container">
          <img src="img/b7ba9547aa700bd20d0420e1794a8jpeg.jpeg" />
          <!---->
         </div><span class="title">麻辣烫</span></a>
        <a href="javascript:" role="button">
         <div class="container">
          <img src="img/ec21096d528b7cfd23cdd894f01c6jpeg.jpeg" />
          <!---->
         </div><span class="title">地方菜系</span></a>
        <a href="javascript:" role="button">
         <div class="container">
          <img src="img/235761e50d391445f021922b71789jpeg.jpeg" />
          <!---->
         </div><span class="title">披萨意面</span></a>
       </div>
       <div class="mint-swipe-item">
        <a href="javascript:" role="button">
         <div class="container">
          <img src="img/6f2631288a44ec177204e05cbcb93jpeg.jpeg" />
          <!---->
         </div><span class="title">地方小吃</span></a>
       </div>
      </div>
      <div class="mint-swipe-indicators" style="">
       <div class="mint-swipe-indicator is-active"></div>
       <div class="mint-swipe-indicator"></div>
      </div>
     </div>
    </div>
    <div>
     <div class="index-1ECZ3_0">
      <section>
       <!---->
       <div class="index-CUiNS_0">
        <img src="static/img/45b2ec2855ed55d90c45bf9b07abbpng.png" ubt-click="101889" ubt-data-message="newuser" />
       </div>
      </section>
      <section id="activity-lego" class="index-1y1Q5_0">
       <div class="index-3xB2N_0">
        <div class="index-3OXhZ_0 index-Q3GS5_0">
         <h3 class="index-1qvN6_0">限量抢购</h3>
         <div class="index-2W67h_0">
          超值美味 9.9元起
         </div>
         <div class="index-1DFa7_0">
          <span>5601人</span>正在抢 &gt;
         </div>
         <img src="static/img/0fa0ed514c093a7138b0b9a50d61fpng.png" />
        </div>
        <div class="index-Q3GS5_0">
         <h3 class="index-1qvN6_0">品质套餐</h3>
         <div class="index-2W67h_0">
          搭配齐全吃得好
         </div>
         <div class="index-1DFa7_0">
          <!---->立即抢购 &gt;
         </div>
         <img src="static/img/16ff085900d62b8d60fa7e9c6b65dpng.png" />
        </div>
       </div>
       <div class="index-QE-ye_0"></div>
      </section>
     </div>
     <!---->
     <!---->
     <div class="backtop BackTop-wrapper_3XDbcaq" style="display: none;">
      <svg class="BackTop-icon_2Js4K94">
       <use xlink:href="#back-top.f9a58c0"></use>
      </svg>
     </div>
    </div>
    <div id="shoplist-title" class="shoplist-title">
     推荐商家
    </div>
    <section class="shoplist">
      <ListItem v-for="data in arr" :key="data.restaurant_id" :restaurant="data"></ListItem>
    </section>
    <footer class="index-wrapper_1Rsz2pX">
     <div class="index-footer_Gtduid_">
      <a href="https://h5.ele.me/msite/" class="index-footerTab_bl0lbJN">
       <svg class="index-footerTabIcon_1EbB8wS">
        <use xlink:href="#index.b8d51ef"></use>
       </svg> <span class="index-footerTabText_1It8yh0 index-footerTabTextActive_3gjOLc6"> 首页 </span></a>
      <a href="https://h5.ele.me/discover/" class="index-footerTab_bl0lbJN">
       <svg class="index-footerTabIcon_1EbB8wS">
        <use xlink:href="#discover-regular.17e03ee"></use>
       </svg> <span class="index-footerTabText_1It8yh0"> 发现 </span></a>
      <a href="https://h5.ele.me/order/" class="index-footerTab_bl0lbJN">
       <svg class="index-footerTabIcon_1EbB8wS">
        <use xlink:href="#order-regular.e1ebaca"></use>
       </svg> <span class="index-footerTabText_1It8yh0"> 订单 </span></a>
      <a href="https://h5.ele.me/profile/" class="index-footerTab_bl0lbJN">
       <svg class="index-footerTabIcon_1EbB8wS">
        <use xlink:href="#profile-regular.813faec"></use>
       </svg> <span class="index-footerTabText_1It8yh0"> 我的 </span></a>
     </div>
    </footer>
  </div>
</template>

<script>
import ListItem from '@/components/list-item'

export default {
  data(){
    return {
      arr: []
    };
  },
  methods: {
    async loadPage(page=0){
      return (await this.axios.get(`restaurant/${page}/8/`)).data;
    }
  },
  components: {ListItem},
  async mounted(){
    this.arr=await this.loadPage(0);
  }
}
</script>

<style lang="css">
*,::after,::before {
    -webkit-box-sizing: inherit;
    box-sizing: inherit;
    -webkit-tap-highlight-color: transparent
}

html {
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #333;
    font-family: 'Helvetica Neue',Tahoma,Arial,PingFangSC-Regular,'Hiragino Sans GB','Microsoft Yahei',sans-serif;
    line-height: 1.2;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    -webkit-font-smoothing: antialiased;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    -webkit-text-size-adjust: none;
    -moz-text-size-adjust: none;
    -ms-text-size-adjust: none;
    text-size-adjust: none
}

body,button,dd,dl,ol,ul {
    margin: 0;
    padding: 0
}

ol,ul {
    list-style: none
}

a {
    outline: 0;
    color: inherit;
    text-decoration: none
}

a,img {
    -webkit-touch-callout: none
}

button,input,select,textarea {
    outline: 0;
    border: none;
    font-size: inherit;
    font-family: inherit
}

h1,h2,h3,h4,h5,h6,p {
    margin: 0;
    font-weight: 400
}

img {
    max-width: 100%
}

textarea {
    resize: none
}

select {
    background-color: transparent;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none
}

input[type=button],input[type=reset],input[type=submit] {
    -webkit-appearance: button;
    -moz-appearance: button;
    appearance: button
}

input:-webkit-autofill {
    -webkit-box-shadow: 0 0 0 100px #fff inset;
    box-shadow: 0 0 0 100px #fff inset
}

.shellAnimation {
    -webkit-animation: shellPulse 1s infinite;
    animation: shellPulse 1s infinite
}

@-webkit-keyframes shellPulse {
    0% {
        opacity: 1
    }

    50% {
        opacity: .6
    }

    100% {
        opacity: 1
    }
}

@keyframes shellPulse {
    0% {
        opacity: 1
    }

    50% {
        opacity: .6
    }

    100% {
        opacity: 1
    }
}

@-webkit-keyframes spinner {
    from {
        -webkit-transform: rotate(0);
        transform: rotate(0)
    }

    to {
        -webkit-transform: rotate(360deg);
        transform: rotate(360deg)
    }
}

@keyframes spinner {
    from {
        -webkit-transform: rotate(0);
        transform: rotate(0)
    }

    to {
        -webkit-transform: rotate(360deg);
        transform: rotate(360deg)
    }
}

.spinner {
    height: 1.333333rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: end;
    -webkit-align-items: flex-end;
    -ms-flex-align: end;
    align-items: flex-end;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center
}

.spinner:after {
    display: block;
    content: '';
    width: 10.24px;
    width: .64rem;
    height: 10.24px;
    height: .64rem;
    -webkit-animation: spinner .5s infinite linear;
    animation: spinner .5s infinite linear;
    border-left: .853px solid transparent;
    border-left: .053333rem solid transparent;
    border-right: .853px solid transparent;
    border-right: .053333rem solid transparent;
    border-bottom: .853px solid transparent;
    border-bottom: .053333rem solid transparent;
    border-top: .853px solid #2395ff;
    border-top: .053333rem solid #2395ff;
    border-radius: 100%
}
</style>
<link rel="stylesheet" href="css/vue-swipe.css" />
<link href="css/msite.css" rel="stylesheet" />
<style type="text/css">
.index-1ECZ3_0 {
margin-bottom: .213333rem;
margin-bottom: 2.133333vw;
font-size: 0
}

.index-1y1Q5_0 {
background: #fff
}

.index-3xB2N_0,.index-QE-ye_0 {
display: -webkit-box;
display: -webkit-flex;
display: -ms-flexbox;
display: flex;
padding: 0 .266667rem;
padding: 0 2.666667vw
}

.index-3xB2N_0 .index-Q3GS5_0,.index-QE-ye_0 .index-Q3GS5_0 {
position: relative;
-webkit-box-flex: 1;
-webkit-flex: 1;
-ms-flex: 1;
flex: 1;
background: -webkit-gradient(linear,left bottom,left top,color-stop(5%,#f4f4f4),color-stop(95%,#fafafa));
background: -webkit-linear-gradient(bottom,#f4f4f4 5%,#fafafa 95%);
background: linear-gradient(0deg,#f4f4f4 5%,#fafafa 95%)
}

.index-3xB2N_0 .index-Q3GS5_0:not(:last-child),.index-QE-ye_0 .index-Q3GS5_0:not(:last-child) {
margin-right: .08rem;
margin-right: .8vw
}

.index-3xB2N_0 {
margin-bottom: .08rem;
margin-bottom: .8vw
}

.index-3xB2N_0 .index-Q3GS5_0 {
height: 3.733333rem;
height: 37.333333vw;
padding: .32rem 0 0 .4rem;
padding: 3.2vw 0 0 4vw;
z-index: 1
}

.index-3xB2N_0 .index-Q3GS5_0 .index-1qvN6_0 {
font-size: .453333rem;
font-weight: 700;
margin-bottom: .133333rem;
margin-bottom: 1.333333vw;
color: #333
}

.index-3xB2N_0 .index-Q3GS5_0 .index-2W67h_0 {
font-size: .346667rem;
color: #777;
margin-bottom: .24rem;
margin-bottom: 2.4vw
}

.index-3xB2N_0 .index-Q3GS5_0 .index-1DFa7_0 {
font-size: .32rem;
color: #af8260;
font-weight: 700
}

.index-3xB2N_0 .index-Q3GS5_0 img {
position: absolute;
right: 0;
bottom: -.2rem;
bottom: -2vw;
width: 3.2rem;
width: 32vw;
height: 2.133333rem;
height: 21.333333vw
}

.index-3xB2N_0 .index-3OXhZ_0 .index-1qvN6_0 {
color: #e81919
}

.index-3xB2N_0 .index-3OXhZ_0 .index-1DFa7_0 {
color: #333
}

.index-3xB2N_0 .index-3OXhZ_0 .index-1DFa7_0>span {
color: #e81919
}

.index-3xB2N_0 .index-1xT5J_0 {
height: 2.933333rem;
height: 29.333333vw
}

.index-3xB2N_0 .index-1xT5J_0 img {
top: .24rem;
top: 2.4vw;
right: .373333rem;
right: 3.733333vw;
width: 3.76rem;
width: 37.6vw;
height: 2.506667rem;
height: 25.066667vw
}

.index-QE-ye_0 {
padding-bottom: .28rem;
padding-bottom: 2.8vw;
display: -webkit-box;
display: -webkit-flex;
display: -ms-flexbox;
display: flex
}

.index-QE-ye_0 .index-Q3GS5_0 {
height: 3.546667rem;
height: 35.466667vw;
text-align: center;
position: relative
}

.index-QE-ye_0 .index-Q3GS5_0 .index-1qvN6_0 {
font-size: .426667rem;
font-weight: 700;
color: #333;
margin: .426667rem 0 .133333rem;
margin: 4.266667vw 0 1.333333vw
}

.index-QE-ye_0 .index-Q3GS5_0 .index-2W67h_0 {
padding: 0 .053333rem;
padding: 0 .533333vw;
font-size: .293333rem;
color: #777;
border-radius: .026667rem;
border-radius: .266667vw;
border: 1px solid #bbb
}

.index-QE-ye_0 .index-Q3GS5_0 img {
position: absolute;
width: 3.093333rem;
width: 30.933333vw;
height: 2.053333rem;
height: 20.533333vw;
bottom: 0;
left: 0
}

.index-QE-ye_0 .index-3Dnrh_0 .index-2W67h_0 {
color: #ff5339;
border-color: #ffa89b
}

.index-CUiNS_0 {
padding: 0 .266667rem;
padding: 0 2.666667vw;
background-color: #fff
}

.index-CUiNS_0 img {
width: 9.466667rem;
width: 94.666667vw;
height: 2.373333rem;
height: 23.733333vw
}

.index-3ZbMh_0 {
display: inline-block;
position: fixed;
right: .16rem;
right: 1.6vw;
bottom: 3.2rem;
bottom: 32vw;
z-index: 100
}

.index-1zDmM_0 {
width: 2.4rem;
width: 24vw
}

.iPhoneXMode .index-3ZbMh_0 {
bottom: 3.653333rem;
bottom: 36.533333vw
}
</style>
